const twilio = require("twilio");
const VoiceResponse = require("twilio/lib/twiml/VoiceResponse");

class Twilio {
  phoneNumber = process.env.MOBILE;
  phoneNumberSid = "PNfbf75f49108407038dfd473eb2f8382c";
  tokenSid = "SK787a5076cb17042c4ad713f3df88dd24";
  tokenSecret = "L6S6jKwzLF0xNn9SVAGEvUm624ZeHl4p";
  accountSid = "AC025e4990084bc9b0b02b1b3674224ee3";
  verify = "VA7b6261cde818120694d1336e3c6f38ac";
  outgoingApplicationSid = "AP69207593dd5b25eac98994fe2c996424";
  client;
  constructor() {
    this.client = twilio(this.tokenSid, this.tokenSecret, {
      accountSid: this.accountSid,
    });
  }

  getTwilio() {
    this.client;
  }

  async sendVerifyAsync(to, channel) {
    const data = await this.client.verify.v2
      .services(this.verify)
      .verifications.create({
        to,
        channel,
      });
    console.log("sendVerify:", data);
    return data;
  }

  async verifyCodeAsync(to, code) {
    const data = await this.client.verify.v2
      .services(this.verify)
      .verificationChecks.create({
        to,
        code,
      });
    console.log("verify code", data);
    return data;
  }

  voiceResponse(message) {
    const twiml = new VoiceResponse();
    twiml.say(
      {
        voice: "female",
      },
      message
    );
    twiml.redirect("https://chirag-callcenter.loca.lt/enqueue");
    return twiml;
  }

  enqueueCall(queueName) {
    const twiml = new VoiceResponse();
    twiml.enqueue(queueName);
    return twiml;
  }

  redirectCall(client) {
    const twiml = new VoiceResponse();
    twiml.dial().client(client);
    return twiml;
  }

  answerCall(sid) {
    console.log("answerCall with sid", sid);
    this.client.calls(sid).update({
      url: "https://chirag-callcenter.loca.lt/connect-call",
      method: "POST",
      function(err, call) {
        console.log("AnswerCall", call);
        if (err) {
          console.error("answerCall", err);
        }
      },
    });
  }

  getAccessTokenForVoice = (identity) => {
    console.log(`Access token for ${identity}`);
    const AccessToken = twilio.jwt.AccessToken;
    const VoiceGrant = AccessToken.VoiceGrant;
    const outgoingAppSid = this.outgoingApplicationSid;
    const voiceGrant = new VoiceGrant({
      outgoingApplicationSid: outgoingAppSid,
      incomingAllow: true,
    });
    const token = new AccessToken(
      this.accountSid,
      this.tokenSid,
      this.tokenSecret,
      { identity }
    );
    token.addGrant(voiceGrant);
    console.log("Access granted with JWT", token.toJwt());
    return token.toJwt();
  };
}

const instance = new Twilio();
Object.freeze(instance);

module.exports = instance;
